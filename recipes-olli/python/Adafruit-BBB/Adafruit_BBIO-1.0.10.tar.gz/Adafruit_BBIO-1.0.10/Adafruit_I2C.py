#!/usr/bin/python

# WARNING: THIS MODULE IS DEPRECATED!
# use Adafruit_GPIO.I2C instead:
# https://github.com/adafruit/Adafruit_Python_GPIO/blob/master/Adafruit_GPIO/I2C.py

class Adafruit_I2C :

  def __init__(self, address, busnum=-1, debug=False):
    print("WARNING: THIS MODULE IS DEPRECATED. Use Adafruit_GPIO.I2C instead.\n");

if __name__ == '__main__':
  print("WARNING: THIS MODULE IS DEPRECATED. Use Adafruit_GPIO.I2C instead.\n");
